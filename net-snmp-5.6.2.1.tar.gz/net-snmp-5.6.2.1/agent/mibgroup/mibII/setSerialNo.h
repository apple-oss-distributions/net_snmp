#ifndef SETSERIALNO_H
#define SETSERIALNO_H

void            init_setSerialNo(void);

#endif                          /* SETSERIALNO_H */
